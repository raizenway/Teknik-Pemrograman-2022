package Birthday;

public class BirthdayMain {

	public static void main(String[] args) {
		Menu run = new Menu();
		run.tampilanMenuUtama();

	}

}
