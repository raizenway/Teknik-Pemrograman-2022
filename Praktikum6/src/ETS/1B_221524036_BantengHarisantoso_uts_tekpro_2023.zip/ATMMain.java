package ETS;


 

public class ATMMain {
   // main method creates and runs the ATM
   public static void main(String[] args) {
      ATM theATM = new ATM();    
      theATM.run();
   }
} 



 